﻿#include "EPD_Test.h"   //Examples

int main(void)
{
    //OLED
    //OLED_1in3_C_test();
    //OLED_2in23_test();
    
    
    //LCD
	//LCD_0in96_test();
    //LCD_1in14_test();
	//LCD_1in3_test();
    //LCD_1in44_test();
    //LCD_1in8_test();
    LCD_2in_test();
    return 0;
}
